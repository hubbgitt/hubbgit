package sailpoint.reporting.datasource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Bundle;
import sailpoint.object.LiveReport;
import sailpoint.object.QueryOptions;
import sailpoint.object.Sort;
import sailpoint.task.Monitor;
import sailpoint.tools.GeneralException;

public class RBCPermittedElementsofBusinessRoleReportDataSource implements JavaDataSource {

	private final int SIZE_ESTIMATE = 1000;
	private SailPointContext context;
	private QueryOptions baseQueryOptions;
	
	private Log logger = LogFactory.getLog("sailpoint.reporting.datasource.RBCPermittedElementsofBusinessRoleReportDataSource");
	
	//Iterator for string-object hashmap
	private Iterator<Map<String, Object>> _objects;
	//String-object hashmap
	private Map<String, Object> _object;
	//List of string-object hashmaps
	List<Map<String, Object>> _objectList = new ArrayList<Map<String, Object>>();
	
	private Integer startRow;
	private Integer pageSize;
	
	private Monitor monitor;
	
	private String businessroles;
	
	private String permittedroles = null;
	
	private String sql = "";
	
	
	Bundle businessRoleName;
	Bundle permittedRoleName;
	
	@Override
	public void initialize(SailPointContext context, LiveReport report, Attributes<String, Object> arguments, String groupBy, List<Sort> sort) throws GeneralException{

		try{
			this.context = context;
			this.baseQueryOptions = new QueryOptions();		//template; no attributes defined

			String businessroles = StringEscapeUtils.escapeSql(arguments.getString("businessroles"));
			this.businessroles = businessroles;		

			String permittedroles = StringEscapeUtils.escapeSql(arguments.getString("permittedroles"));
			this.permittedroles = permittedroles;;

			if (permittedroles != null){	
				businessRoleName = context.getObjectById(Bundle.class, businessroles);
				businessroles = businessRoleName.getName();
				permittedRoleName = context.getObjectById(Bundle.class, permittedroles);
				permittedroles = permittedRoleName.getName();
				sql += "sql: ";
				sql += "SELECT ";
				sql += "b1.name as Business_Role, ";
				sql += "b2.name as Permitted_Role, ";
				sql += "i.firstname as First_Name, ";
				sql += "i.lastname as Last_Name, ";
				sql += "i.display_name as Identity_Name, ";
				sql += "i.name as RBC_ID, ";
				sql += "i.extended3 as RBC_BUFUGU ";
				sql += "from spt_bundle_permits p ";
				sql += "LEFT OUTER JOIN spt_bundle b1 ";
				sql += "ON b1.id = p.bundle ";
				sql += "LEFT OUTER JOIN spt_bundle b2 ";
				sql += "ON b2.id = p.child ";
				sql += "LEFT OUTER JOIN spt_identity_bundles ib ";
				sql += "ON ib.bundle = p.child ";
				sql += "LEFT OUTER JOIN spt_identity i ";
				sql += "ON i.id = ib.identity_id ";
				sql += "WHERE b1.name = '" + businessroles + "' ";
				sql += "AND b2.name = '" + permittedroles + "' ";
			}
			else {
				businessRoleName = context.getObjectById(Bundle.class, businessroles);
				businessroles = businessRoleName.getName();
				sql += "sql: ";
				sql += "SELECT ";
				sql += "b1.name as Business_Role, ";
				sql += "b2.name as Permitted_Role, ";
				sql += "i.firstname as First_Name, ";
				sql += "i.lastname as Last_Name, ";
				sql += "i.display_name as Identity_Name, ";
				sql += "i.name as RBC_ID, ";
				sql += "i.extended3 as RBC_BUFUGU ";
				sql += "from spt_bundle_permits p ";
				sql += "LEFT OUTER JOIN spt_bundle b1 ";
				sql += "ON b1.id = p.bundle ";
				sql += "LEFT OUTER JOIN spt_bundle b2 ";
				sql += "ON b2.id = p.child ";
				sql += "LEFT OUTER JOIN spt_identity_bundles ib ";
				sql += "ON ib.bundle = p.child ";
				sql += "LEFT OUTER JOIN spt_identity i ";
				sql += "ON i.id = ib.identity_id ";
				sql += "WHERE b1.name = '" + businessroles + "' ";				
			}
			prepare();
		}
		catch (Exception e){
			this.logger.error("Exception : " + e.getMessage());
		}

	}


	public void prepare(){

		try {
			Iterator<Object[]> iterator = context.search(sql, null, null);
			while (iterator.hasNext()){
				Object[] row = iterator.next();

				//String-object hashmap
				Map<String, Object> itemMap = new HashMap<String, Object>();

				itemMap.put("BusinessRole", row[0]);
				itemMap.put("PermittedRole", row[1]);
				itemMap.put("FirstName", row[2]);
				itemMap.put("LastName", row[3]);
				itemMap.put("IdentityName", row[4]);
				itemMap.put("RBCID", row[5]);
				itemMap.put("RBCBUFUGU", row[6]);

				this._objectList.add(itemMap);
			}

			this._objects = this._objectList.iterator();					
		} catch (GeneralException e) {
			this.logger.error("Exception : " + e.getMessage());
		}
	}

	
	@Override
	public String getBaseHql()
	{
		//Unused.
		
		return null;
	}

	@Override
	public QueryOptions getBaseQueryOptions(){
		return this.baseQueryOptions;
	}

	@Override
	public Object getFieldValue(String fieldName) throws GeneralException{
		if (_object.containsKey(fieldName)){
			return _object.get(fieldName);
		}else{
			throw new GeneralException("Unknown column: '" + fieldName + "'");
		}
	}

	@Override
	public int getSizeEstimate() throws GeneralException{
		return SIZE_ESTIMATE;
	}

	@Override
	public void close(){
		//Do nothing.
	}

	@Override
	public void setMonitor(Monitor monitor){
		this.monitor = monitor;
	}

	@Override
	public Object getFieldValue(JRField jrField) throws JRException{
		String fieldName = jrField.getName();

		try{
			return this.getFieldValue(fieldName);
		}
		catch (GeneralException e){
			throw new JRException(e);
		}
	}

	@Override
	public boolean next() throws JRException{
		boolean hasMore = false;
		
		if (this._objects != null){
			hasMore = this._objects.hasNext();
			
			if (hasMore){
				this._object = this._objects.next();
			}else{
				this._object = null;
			}
		}
		
		return hasMore;
	}

	@Override
	public void setLimit(int startRow, int pageSize){
		this.startRow = startRow;
		this.pageSize = pageSize;
	}
}
