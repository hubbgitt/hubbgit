package sailpoint.reporting.datasource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import net.sf.jasperreports.engine.JRException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.api.SailPointContext;
import sailpoint.object.Attributes;
import sailpoint.object.Bundle;
import sailpoint.object.EntitlementGroup;
import sailpoint.object.Identity;
import sailpoint.object.LiveReport;
import sailpoint.object.QueryOptions;
import sailpoint.object.RoleAssignment;
import sailpoint.object.Sort;
import sailpoint.reporting.ReportHelper;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Util;

public class RBCActualVsRequestedAccessDataSource extends ProjectionDataSource
implements JavaDataSource {

	private static final Log log=LogFactory.getLog(RBCActualVsRequestedAccessDataSource.class);;

	private SailPointContext context;
	private List<IdentityData> identityDataList = new ArrayList<IdentityData>();
	private Iterator identityDataIter;
	private IdentityData identityDataObj;
	private String currentIdentityDataId;

	private Object identityArgObj;
	private Object managerArgObj;
	private Object rbcStatusArgObj;
	private Object rbcBUFUGUArgObj;
	private Object entitlementArgObj;
	private Object mdsAdSAMAccountNameArgObj;
	private Object businessPurposeCodeArgObj;
	private Object assignedArgObj;
	private Object assignedBusinessRoleArgObj;
	private Object detectedITRoleArgObj;
	private Object notDetectedITRoleArgObj;
	private Object assignedByArgObj;
	private Object sourceArgObj;




	
	public RBCActualVsRequestedAccessDataSource() {  }
	public RBCActualVsRequestedAccessDataSource(SailPointContext context) {
		this.context = context;
	}

	public void initialize(SailPointContext context, LiveReport report, Attributes<String, Object> arguments, String groupBy, List<Sort> sort) {
		try {
			this.context = context;
			super.setTimezone((TimeZone)arguments.get("REPORT_TIME_ZONE"));
			super.setLocale((Locale)arguments.get("REPORT_LOCALE"));

			ReportHelper helper = new ReportHelper(context, getLocale(), getTimezone());

			QueryOptions ops = helper.getFilterQueryOps(report, arguments);
			log.debug("queryOptions before init: " + ops );
			log.debug("Attributes<String, Object> arguments: " + arguments.size() + ":" + arguments);


			identityArgObj = arguments.getList("identity");
			managerArgObj = arguments.getList("manager");
			rbcStatusArgObj = arguments.getList("rbcStatus");
			rbcBUFUGUArgObj = arguments.getList("rbcBUFUGU");
			entitlementArgObj = arguments.getList("entitlement");




			mdsAdSAMAccountNameArgObj = arguments.getList("mdsAdSAMAccountName");
			businessPurposeCodeArgObj = arguments.getList("businessPurposeCode");
			assignedArgObj = arguments.getList("assigned");


			assignedBusinessRoleArgObj = arguments.getList("assignedBusinessRole");
			detectedITRoleArgObj = arguments.getList("detectedITRole");
			notDetectedITRoleArgObj = arguments.getList("notDetectedITRole");
			assignedByArgObj = arguments.getList("assignedBy");
			sourceArgObj = arguments.getList("source");

			if(identityArgObj != null) {
				log.debug("identityArgObj: " + identityArgObj);
				log.debug("identityArgObj 0 : " + ((List)identityArgObj).get(0) + " : " + ((List)identityArgObj).get(0));
				//ops.addFilter(Filter.in("id", value))
			}
			
			List cols = new ArrayList();
			//cols.add(new ReportColumnConfig(COL_ID, "id"));
			cols.addAll(report.getGridColumns());
			log.debug("cols: "+ cols.size()+":"+cols);

			initIdentityDataList();
			log.debug("before init");
			init(Identity.class, ops, cols, getLocale(), getTimezone());
			log.debug("after init");

		} catch (GeneralException e) {
			log.error(e.getLocalizedMessage(), e); 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public boolean next() throws JRException {
		log.debug("this.currentIdentityDataId " +this.currentIdentityDataId);
		boolean boolResult = false;
		try{
			this.identityDataObj = null;
			log.debug("Before if(this.identityDataIter != null");

			if(this.identityDataIter == null){
				this.identityDataIter = identityDataList.iterator();
			}

			if(this.identityDataIter.hasNext()){
				Object objTemp = this.identityDataIter.next();
				this.identityDataObj = (IdentityData) objTemp;
				log.debug("this.identityDataObj: " + this.identityDataObj);
			}

			boolResult = this.identityDataObj != null;
			log.debug("next(): boolResult: " + boolResult);
		} catch(Exception e){
			log.error("Exception during next()" + e);
			throw new JRException(e);
		}
		return boolResult;
	}


	@Override
	public void setLimit(int arg0, int arg1) {

	}



	/**


	 * Required to map ReportColumnConfig field to IdentityWithEntitlements instance variables
	 * @throws GeneralException 
	 */
	public Object getFieldValue(String fieldName) throws GeneralException {
		log.debug("Inside getFieldValue, fieldName: " +fieldName);
		Object value = null;
		try {
			if (this.identityDataObj != null)
				if (fieldName.equals("id"))
					value = this.identityDataObj.id;
				else if (fieldName.equals("created"))
					value = this.identityDataObj.created;
				else if (fieldName.equals("identityName"))
					value = this.identityDataObj.identityName;
				else if (fieldName.equals("identityFullName"))
					value = this.identityDataObj.identityFullName;
				else if (fieldName.equals("managerName"))
					value = this.identityDataObj.managerName;
				else if (fieldName.equals("managerFullName"))
					value = this.identityDataObj.managerFullName;
				else if (fieldName.equals("rbcStatus"))
					value = this.identityDataObj.rbcStatus;
				else if (fieldName.equals("rbcBUFUGU"))
					value = this.identityDataObj.rbcBUFUGU;
				else if (fieldName.equals("entitlement"))
					value = this.identityDataObj.entitlement;
				else if (fieldName.equals("mdsAdSAMAccountName"))
					value = this.identityDataObj.mdsAdSAMAccountName;
				else if (fieldName.equals("businessPurposeCode"))
					value = this.identityDataObj.businessPurposeCode;
				else if (fieldName.equals("assigned"))
					value = this.identityDataObj.assigned;
				else if (fieldName.equals("assignedBusinessRole"))
					value = this.identityDataObj.assignedBusinessRoleName;
				else if (fieldName.equals("detectedITRole"))
					value = this.identityDataObj.detectedITRoleName;
				else if (fieldName.equals("notDetectedITRole"))
					value = this.identityDataObj.notDetectedITRoleName;
				else if (fieldName.equals("assignedBy"))
					value = this.identityDataObj.assignedBy;
				else if (fieldName.equals("source"))
					value = this.identityDataObj.source;

			if(value==null){
				value = super.getFieldValue(fieldName);
			}
		} catch (GeneralException localThrowable) { 


			throw localThrowable; 
		}
		log.debug("End of getFieldValue(): fieldName: " + fieldName + "; value: " + value);

		return value;
	}

	private class IdentityData{
		String id;
		String created;
		String identityName;
		String identityFullName;
		String managerName;
		String managerFullName;
		String rbcStatus;
		String rbcBUFUGU;
		String entitlement;
		String mdsAdSAMAccountName;
		String businessPurposeCode;
		String assigned;
		String assignedBusinessRoleID;
		String assignedBusinessRoleName;
		String detectedITRoleID;
		String detectedITRoleName;
		String notDetectedITRoleID;
		String notDetectedITRoleName;
		String assignedBy;
		String source;

		@Override
		public String toString() {
			return "IdentityData [id=" + id + ", created=" + created + ", identityName=" + identityName

					+ ", identityFullName=" + identityFullName + ", managerName=" + managerName + ", managerFullName="
					+ managerFullName + ", rbcStatus=" + rbcStatus + ", rbcBUFUGU=" + rbcBUFUGU + ", entitlement="

					+ entitlement + ", mdsAdSAMAccountName=" + mdsAdSAMAccountName + ", businessPurposeCode="

					+ businessPurposeCode + ", assigned=" + assigned + ", assignedBusinessRoleID="

					+ assignedBusinessRoleID + ", assignedBusinessRoleName=" + assignedBusinessRoleName
					+ ", detectedITRoleID=" + detectedITRoleID + ", detectedITRoleName=" + detectedITRoleName

					+ ", notDetectedITRoleID=" + notDetectedITRoleID + ", notDetectedITRoleName="

					+ notDetectedITRoleName + ", assignedBy=" + assignedBy + ", source=" + source + "]";
		}


	}

	public void initIdentityDataList() throws Exception{
		Iterator identityIter = context.search(Identity.class, new QueryOptions(), 

				Arrays.asList(new String[]{"id", "created", "name"}));

		List<String> identityIDSelectedList = new ArrayList<String>();
		List<String> managerNameSelectedList = new ArrayList<String>();
		List<String> employeeStatusSelectedList = new ArrayList<String>();
		List<String> rbcBufuguSelectedList = new ArrayList<String>();
		List<String> entitlementSelectedList = new ArrayList<String>();
		List<String> accountNameSelectedList = new ArrayList<String>();
		List<String> businessAppCodeSelectedList = new ArrayList<String>();
		List<String>	assignedSelectedList = new ArrayList<String>();
		List<String> assignedBusinessRoleSelectedList = new ArrayList<String>();
		List<String> detectedITRoleSelectedList = new ArrayList<String>();
		List<String> notDetectedITRoleSelectedList = new ArrayList<String>();
		List<String> assignedBySelectedList = new ArrayList<String>();
		List<String> sourceSelectedList = new ArrayList<String>();


		if(identityArgObj != null){
			Object obj = identityArgObj;
			if(obj != null){
				if(obj instanceof String){
					identityIDSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							identityIDSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//identity

		//identityIDList.add("40282e0660e8b2c80160e8b3c1000038"); //298406810, 40282e0660e8b2c80160e8b3c1000038


		if(managerArgObj != null){
			Object obj = managerArgObj;
			if(obj != null){
				if(obj instanceof String){
					managerNameSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							managerNameSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//manager

		if(rbcStatusArgObj != null){
			Object obj = rbcStatusArgObj;
			if(obj != null){
				if(obj instanceof String){
					employeeStatusSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							employeeStatusSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//rbcStatus

		if(rbcBUFUGUArgObj != null){
			Object obj = rbcBUFUGUArgObj;
			if(obj != null){
				if(obj instanceof String){
					rbcBufuguSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							rbcBufuguSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//rbcBUFUGU

		if(entitlementArgObj != null){
			Object obj = entitlementArgObj;
			if(obj != null){
				if(obj instanceof String){
					entitlementSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							entitlementSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//entitlement

		if(mdsAdSAMAccountNameArgObj != null){
			Object obj = mdsAdSAMAccountNameArgObj;
			if(obj != null){
				if(obj instanceof String){
					accountNameSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							accountNameSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//mdsAdSAMAccountName

		if(businessPurposeCodeArgObj != null){
			Object obj = businessPurposeCodeArgObj;
			if(obj != null){
				if(obj instanceof String){
					businessAppCodeSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							businessAppCodeSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//businessPurposeCode

		if(assignedArgObj != null){
			Object obj = assignedArgObj;
			if(obj != null){
				if(obj instanceof String){
					assignedSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							assignedSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//assigned


		if(assignedBusinessRoleArgObj != null){
			Object obj = assignedBusinessRoleArgObj;
			if(obj != null){
				if(obj instanceof String){
					assignedBusinessRoleSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							assignedBusinessRoleSelectedList.add("" + elementObj);

						}
					}
				}
			}
		}//assignedBusinessRole

		if(detectedITRoleArgObj != null){
			Object obj = detectedITRoleArgObj;
			if(obj != null){
				if(obj instanceof String){
					detectedITRoleSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							detectedITRoleSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//detectedITRole

		if(notDetectedITRoleArgObj != null){
			Object obj = notDetectedITRoleArgObj;
			if(obj != null){
				if(obj instanceof String){
					notDetectedITRoleSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							notDetectedITRoleSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//notDetectedITRole

		if(assignedByArgObj != null){
			Object obj = assignedByArgObj;
			if(obj != null){
				if(obj instanceof String){
					assignedBySelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							assignedBySelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//assignedBy

		if(sourceArgObj != null){
			Object obj = sourceArgObj;
			if(obj != null){
				if(obj instanceof String){
					sourceSelectedList.add("" + obj);
				}
				else if(obj instanceof List){
					List tempList = (List) obj;
					for(Object elementObj: tempList){
						if(elementObj != null){
							sourceSelectedList.add("" + elementObj);
						}
					}
				}
			}
		}//source

		log.debug("identityIDList: " + identityIDSelectedList);
		log.debug("managerNameList: " + managerNameSelectedList);
		log.debug("employeeStatusList: " + employeeStatusSelectedList);
		log.debug("rbcBufuguList: " + rbcBufuguSelectedList);
		log.debug("entitlementList: " + entitlementSelectedList);
		log.debug("accountNameList: " + accountNameSelectedList);
		log.debug("businessAppCodeList: " + businessAppCodeSelectedList);
		log.debug("assignedList: " + assignedSelectedList);
		log.debug("assignedBusinessRoleList: " + assignedBusinessRoleSelectedList);

		log.debug("detectedITRoleList: " + detectedITRoleSelectedList);
		log.debug("notDetectedITRoleList: " + notDetectedITRoleSelectedList);
		log.debug("assignedByList: " + assignedBySelectedList);
		log.debug("sourceList: " + sourceSelectedList);

		int countIdentityIter = -1;
		while(identityIter.hasNext()){
			String identityID = "";
			String identityName = "";
			String identityFullName = "";
			String managerName = "";
			String managerFullName = "";
			String rbcStatus = "";
			String rbcBUFUGU = "";
			String entitlement = "";
			String mdsAdSAMAccountName = "";
			String businessPurposeCode = "";
			String assigned = "";
			String assignedBusinessRoleID = "";
			String assignedBusinessRoleName = "";
			String detectedITRoleID = "";
			String detectedITRoleName = "";
			String notDetectedITRoleID = "";
			String notDetectedITRoleName = "";
			String assignedBy = "";
			String source = "";

			Object[] arr = (Object[]) identityIter.next();
			log.debug("" + (++countIdentityIter) + ": it.next: " + Arrays.asList( arr ));

			IdentityData identityDataObj = new IdentityData();
			identityID = "" + arr[0];
			identityDataObj.created = "" + arr[1];

			Identity identityObj = context.getObjectById(Identity.class, identityID);

			log.debug("identityObj: " + identityObj);

			if(identityObj != null){

				identityName = identityObj.getName();

				//identityFullName
				if(identityObj.getFirstname() != null){
					identityFullName = identityObj.getFirstname();
				}
				if(identityObj.getLastname() != null){
					if(!identityFullName.isEmpty()){
						identityFullName += " ";
					}
					identityFullName = identityObj.getLastname();
				}

				//manager
				if(identityObj.getManager() != null){
					Identity managerIdentity = identityObj.getManager();
					managerName = managerIdentity.getName();
					//managerFullName = managerIdentity.getFullName();

					if(managerIdentity.getFirstname() != null){
						managerFullName = managerIdentity.getFirstname();
					}
					if(managerIdentity.getLastname() != null){
						if(!managerFullName.isEmpty()){
							managerFullName += " ";
						}
						managerFullName = identityObj.getLastname();
					}
				}//end of if manager is not null

				if(identityObj.getAttribute("rbcStatus") != null){
					rbcStatus = "" + identityObj.getAttribute("rbcStatus");
				}

				if(identityObj.getAttribute("rbcBUFUGU") != null){
					rbcBUFUGU = "" + identityObj.getAttribute("rbcBUFUGU");

				}


				//entitlementSet
				String entitlementUnique="", entitlementAll="";
				Set<String> entitlementSet = new HashSet<String>();
				List<String> entitlementList = new ArrayList<String>();
				List entitlementGroupList = identityObj.getExceptions();
				if(entitlementGroupList != null){
					for(Object entitlementGroupObj: entitlementGroupList){
						EntitlementGroup entitlementGroup = (EntitlementGroup) entitlementGroupObj;


						Attributes attributes = entitlementGroup.getAttributes();
						if(attributes != null){


							Object permissionSetObj = attributes.get("permissionsets");
							if(permissionSetObj != null){
								List permissionSetList = (List) permissionSetObj;
								entitlementSet.addAll(permissionSetList);
								if(!entitlementAll.isEmpty()){
									entitlementAll += "; ";
								}


								entitlementAll += Util.listToCsv(permissionSetList);
							}//end of if permissionSetObj is not null
						}//end of if attributes is not null
					}//iterate through entitlementGroupList
				}//if entitlementGroupList is not null

				entitlementList.addAll(entitlementSet);


				Collections.sort(entitlementList, String.CASE_INSENSITIVE_ORDER);
				log.debug("entitlementList: " + (entitlementList==null ? "null" : "" + entitlementList/*.size()*/));


				entitlementUnique = Util.listToCsv(entitlementList);

				entitlement = entitlementAll;

				//mdsAdSAMAccountName
				if(identityObj.getAttribute("mdsAdSAMAccountName") != null){
					mdsAdSAMAccountName = "" + identityObj.getAttribute("mdsAdSAMAccountName");;


				}

				//businessPurposeCode
				if(identityObj.getAttribute("businessPurposeCode") != null){
					businessPurposeCode = "" + identityObj.getAttribute("businessPurposeCode");;


				}



				//assigned and assignedBusinessRoleSet
				assigned = "No";
				Set<String> assignedBusinessRoleIDSet = new LinkedHashSet<String>();
				Map<String,String> assignedBusinessRoleMap = new HashMap<String,String>();
				List<Bundle> bundleList = identityObj.getAssignedRoles();
				if(bundleList != null){
					for(Bundle bundle: bundleList){

						if(bundle != null){
							assigned = "Yes";

							String bundleTypeStr = "" + bundle.getType();
							if(bundle.getName() != null){
								if(bundleTypeStr.equalsIgnoreCase("business"))
								{
									String bundleIdStr = bundle.getId();
									assignedBusinessRoleIDSet.add(bundleIdStr);
									assignedBusinessRoleMap.put(bundleIdStr, bundle.getName());

								}
							}//end of if bundle name is not null
						}//end of if bundleObj is not null
					}//iterate through bundleList
				}//end of if bundleList is not null

				//assignedBusinessRoleID = Util.setToCsv(assignedBusinessRoleIDSet);

				//assignedBusinessRoleName = Util.setToCsv(assignedBusinessRoleMap.values());


				if(!assignedBusinessRoleIDSet.isEmpty()){
					for(String businessRoleNameStr: assignedBusinessRoleIDSet){

						//iterate through assigned roles
						if(assignedBusinessRoleMap.get(businessRoleNameStr) != null){
							assignedBusinessRoleID = businessRoleNameStr;




							assignedBusinessRoleName = assignedBusinessRoleMap.get(businessRoleNameStr);
							List<String> sourceAssignerList = getSourceAssigner(identityObj, assignedBusinessRoleID);
							if(sourceAssignerList != null && sourceAssignerList.size() >= 2){

								assignedBy = sourceAssignerList.get(0);
								source = sourceAssignerList.get(1);
							}

							
							//detectedITRoleSet
							Set<String> detectedITRoleSet = new LinkedHashSet<String>();
							Map<String, String> detectedITRoleMap = new HashMap<String,String>();

							Set<String> notDetectedITRoleSet = new LinkedHashSet<String>();
							Map<String, String> notDetectedITRoleMap = new HashMap<String,String>();
							List<Bundle> detectedBundleList = identityObj.getDetectedRoles();
							
							if(bundleList != null){



								for(Bundle bundle: bundleList){
									if(bundle != null){
										String bundleTypeStr = bundle.getType();

										if(detectedBundleList.contains(bundle))
										
										if(bundle.getName() != null){
											//if(bundleTypeStr.equalsIgnoreCase("it"))
											{


												detectedITRoleSet.add(bundle.getId());
												detectedITRoleMap.put(bundle.getId(), bundle.getName());


											}
										}//end of if bundle name is not null
									}//end of if bundleObj is not null
								}//iterate through bundleList
							}//end of if bundleList is not null

							if(!detectedITRoleSet.isEmpty()){
								for(String detectedITRoleIDStr: detectedITRoleSet){
									if(detectedITRoleMap.get(detectedITRoleIDStr) != null){



										detectedITRoleName = detectedITRoleMap.get(detectedITRoleIDStr);
										detectedITRoleID = detectedITRoleIDStr;

										
										
										IdentityData identityDataObjPerITRole = new IdentityData();
										identityDataObjPerITRole.id = identityID;
										identityDataObjPerITRole.identityName = identityName;
										identityDataObjPerITRole.identityFullName = identityFullName;
										identityDataObjPerITRole.managerName = managerName;
										identityDataObjPerITRole.managerFullName = managerFullName;
										identityDataObjPerITRole.rbcStatus = rbcStatus;
										identityDataObjPerITRole.rbcBUFUGU = rbcBUFUGU;
										identityDataObjPerITRole.entitlement = entitlement;
										identityDataObjPerITRole.mdsAdSAMAccountName = mdsAdSAMAccountName;
										identityDataObjPerITRole.businessPurposeCode = businessPurposeCode;
										identityDataObjPerITRole.assigned = assigned;
										identityDataObjPerITRole.assignedBusinessRoleID = assignedBusinessRoleID;
										identityDataObjPerITRole.assignedBusinessRoleName = assignedBusinessRoleName;
										identityDataObjPerITRole.detectedITRoleID = detectedITRoleID;
										identityDataObjPerITRole.detectedITRoleName = detectedITRoleName;
										identityDataObjPerITRole.assignedBy = assignedBy;
										identityDataObjPerITRole.source = source;
										
										//add object to list if form filters are satisfied
										if(
												(identityIDSelectedList.isEmpty() || (identityIDSelectedList.contains(identityID)))
												&& (managerNameSelectedList.isEmpty() || (managerNameSelectedList.contains(managerName)))
												&& (employeeStatusSelectedList.isEmpty() || (employeeStatusSelectedList.contains(rbcStatus)))
												&& (rbcBufuguSelectedList.isEmpty() || (rbcBufuguSelectedList.contains(rbcBUFUGU)))
												&& (entitlementSelectedList.isEmpty() || (!Collections.disjoint(entitlementSelectedList, entitlementList)))
												&& (accountNameSelectedList.isEmpty() || (accountNameSelectedList.contains(mdsAdSAMAccountName)))
												&& (businessAppCodeSelectedList.isEmpty() || (businessAppCodeSelectedList.contains(businessPurposeCode)))
												&& (assignedSelectedList.isEmpty() || (assignedSelectedList.contains(assigned)))
												&& (assignedBusinessRoleSelectedList.isEmpty() || (assignedBusinessRoleSelectedList.contains(assignedBusinessRoleName)))
												&& (detectedITRoleSelectedList.isEmpty() || (detectedITRoleSelectedList.contains(detectedITRoleName)))
												&& (notDetectedITRoleSelectedList.isEmpty() || (notDetectedITRoleSelectedList.contains(notDetectedITRoleName)))
												&& (assignedBySelectedList.isEmpty() || (assignedBySelectedList.contains(assignedBy)))
												&& (sourceSelectedList.isEmpty() || (sourceSelectedList.contains(source)))











































												){
											log.debug("identityIDList.isEmpty() || (identityIDList.contains(identityID)): " + (identityIDSelectedList.isEmpty() || (identityIDSelectedList.contains(identityID))));
											identityDataList.add(identityDataObjPerITRole);
											log.debug("identityDataObj added; identityDataList size = " + identityDataList.size()); 
										}


										
									}//if detectedITRoleMap get detectedITRoleIDStr is not null
								}//iterate through detectedITRoleSet
							}//end of detectedITRoleSet is not empty


							

							if(!notDetectedITRoleSet.isEmpty()){
								for(String notDetectedITRoleIDStr: notDetectedITRoleSet){
									if(notDetectedITRoleMap.get(notDetectedITRoleIDStr) != null){
										notDetectedITRoleName = notDetectedITRoleMap.get(notDetectedITRoleIDStr);
										notDetectedITRoleID = notDetectedITRoleIDStr;

										
										
										IdentityData identityDataObjPerITRole = new IdentityData();
										identityDataObjPerITRole.id = identityID;
										identityDataObjPerITRole.identityName = identityName;
										identityDataObjPerITRole.identityFullName = identityFullName;
										identityDataObjPerITRole.managerName = managerName;
										identityDataObjPerITRole.managerFullName = managerFullName;
										identityDataObjPerITRole.rbcStatus = rbcStatus;
										identityDataObjPerITRole.rbcBUFUGU = rbcBUFUGU;
										identityDataObjPerITRole.entitlement = entitlement;
										identityDataObjPerITRole.mdsAdSAMAccountName = mdsAdSAMAccountName;
										identityDataObjPerITRole.businessPurposeCode = businessPurposeCode;
										identityDataObjPerITRole.assigned = assigned;
										identityDataObjPerITRole.assignedBusinessRoleID = assignedBusinessRoleID;
										identityDataObjPerITRole.assignedBusinessRoleName = assignedBusinessRoleName;
										identityDataObjPerITRole.detectedITRoleID = detectedITRoleID;
										identityDataObjPerITRole.detectedITRoleName = detectedITRoleName;
										identityDataObjPerITRole.assignedBy = assignedBy;
										identityDataObjPerITRole.source = source;
										
										//add object to list if form filters are satisfied
										if(
												(identityIDSelectedList.isEmpty() || (identityIDSelectedList.contains(identityID)))
												&& (managerNameSelectedList.isEmpty() || (managerNameSelectedList.contains(managerName)))
												&& (employeeStatusSelectedList.isEmpty() || (employeeStatusSelectedList.contains(rbcStatus)))
												&& (rbcBufuguSelectedList.isEmpty() || (rbcBufuguSelectedList.contains(rbcBUFUGU)))
												&& (entitlementSelectedList.isEmpty() || (!Collections.disjoint(entitlementSelectedList, entitlementList)))
												&& (accountNameSelectedList.isEmpty() || (accountNameSelectedList.contains(mdsAdSAMAccountName)))
												&& (businessAppCodeSelectedList.isEmpty() || (businessAppCodeSelectedList.contains(businessPurposeCode)))
												&& (assignedSelectedList.isEmpty() || (assignedSelectedList.contains(assigned)))
												&& (assignedBusinessRoleSelectedList.isEmpty() || (assignedBusinessRoleSelectedList.contains(assignedBusinessRoleName)))
												&& (detectedITRoleSelectedList.isEmpty() || (detectedITRoleSelectedList.contains(detectedITRoleName)))
												&& (notDetectedITRoleSelectedList.isEmpty() || (notDetectedITRoleSelectedList.contains(notDetectedITRoleName)))
												&& (assignedBySelectedList.isEmpty() || (assignedBySelectedList.contains(assignedBy)))
												&& (sourceSelectedList.isEmpty() || (sourceSelectedList.contains(source)))

												){
											log.debug("identityIDList.isEmpty() || (identityIDList.contains(identityID)): " + (identityIDSelectedList.isEmpty() || (identityIDSelectedList.contains(identityID))));





											identityDataList.add(identityDataObjPerITRole);
											log.debug("identityDataObj added; identityDataList size = " + identityDataList.size()); 

										}

										
									}//if detectedITRoleMap get detectedITRoleIDStr is not null

								}//iterate through detectedITRoleSet
							}//end of detectedITRoleSet is not empty

						}//end of assignedBusinessRoleMap get businessRoleNameStr is not null

					}//for loop, iterate through assignedBusinessRoleIDSet
				}//end of if assignedBusinessRoleIDSet is not null

				else{
					identityDataObj.id = identityID;
					identityDataObj.identityName = identityName;
					identityDataObj.identityFullName = identityFullName;
					identityDataObj.managerName = managerName;
					identityDataObj.managerFullName = managerFullName;
					identityDataObj.rbcStatus = rbcStatus;
					identityDataObj.rbcBUFUGU = rbcBUFUGU;
					identityDataObj.entitlement = entitlement;
					identityDataObj.mdsAdSAMAccountName = mdsAdSAMAccountName;
					identityDataObj.businessPurposeCode = businessPurposeCode;
					identityDataObj.assigned = assigned;
					identityDataObj.assignedBusinessRoleID = assignedBusinessRoleID;
					identityDataObj.assignedBusinessRoleName = assignedBusinessRoleName;
					identityDataObj.detectedITRoleID = detectedITRoleID;
					identityDataObj.detectedITRoleName = detectedITRoleName;
					identityDataObj.notDetectedITRoleID = notDetectedITRoleID;
					identityDataObj.notDetectedITRoleName = notDetectedITRoleName;
					identityDataObj.assignedBy = assignedBy;
					identityDataObj.source = source;
					log.debug("" + countIdentityIter + ": identityDataObj: " + identityDataObj);


					//add object to list if form filters are satisfied
					if(
							(identityIDSelectedList.isEmpty() || (identityIDSelectedList.contains(identityID)))







							&& (managerNameSelectedList.isEmpty() || (managerNameSelectedList.contains(managerName)))
							&& (employeeStatusSelectedList.isEmpty() || (employeeStatusSelectedList.contains(rbcStatus)))
							&& (rbcBufuguSelectedList.isEmpty() || (rbcBufuguSelectedList.contains(rbcBUFUGU)))
							&& (entitlementSelectedList.isEmpty() || (!Collections.disjoint(entitlementSelectedList, entitlementList)))


















							&& (accountNameSelectedList.isEmpty() || (accountNameSelectedList.contains(mdsAdSAMAccountName)))
							&& (businessAppCodeSelectedList.isEmpty() || (businessAppCodeSelectedList.contains(businessPurposeCode)))
							&& (assignedSelectedList.isEmpty() || (assignedSelectedList.contains(assigned)))
							&& (assignedBusinessRoleSelectedList.isEmpty() || (assignedBusinessRoleSelectedList.contains(assignedBusinessRoleName)))
							&& (detectedITRoleSelectedList.isEmpty() || (detectedITRoleSelectedList.contains(detectedITRoleName)))
							&& (notDetectedITRoleSelectedList.isEmpty() || (notDetectedITRoleSelectedList.contains(notDetectedITRoleName)))
							&& (assignedBySelectedList.isEmpty() || (assignedBySelectedList.contains(assignedBy)))
							&& (sourceSelectedList.isEmpty() || (sourceSelectedList.contains(source)))


							){
						log.debug("identityIDList.isEmpty() || (identityIDList.contains(identityID)): " + (identityIDSelectedList.isEmpty() || (identityIDSelectedList.contains(identityID))));


						identityDataList.add(identityDataObj);
						log.debug("identityDataObj added; identityDataList size = " + identityDataList.size()); 





					}//end of add object to list if form filters are satisfied




				}//else of if assignedBusinessRoleIDSet is not empty







			}//end of if identityObj is not null
			log.debug("identityDataObj: " + identityDataObj);
		}//end of while identityIter has next

		log.debug("end of initIdentityDataList(): identityDataList size: " + identityDataList.size()); 
	}//end of initIdentityDataList method

	
	private List<String> getSourceAssigner(Identity identityObj, String bundleId){
		List<String> resultList = new ArrayList<String>();
		String roleAssigner = "";
		String roleAssignSource = "";

		
		
		Object identityPreferenceObj = identityObj.getPreference("roleAssignments");

		if(identityPreferenceObj != null){
			if(identityPreferenceObj instanceof List){
				List roleAssignmentList = (List) identityPreferenceObj;
				for(Object roleAssignmentObj: roleAssignmentList){
					if(roleAssignmentObj != null){
						RoleAssignment roleAssignment = (RoleAssignment) roleAssignmentObj;
						if(roleAssignment.getRoleId().equalsIgnoreCase(bundleId)){

							if(roleAssignment.getAssigner() != null){
								roleAssigner = roleAssignment.getAssigner(); //eg spadmin

							}//end of if roleAssignment assigner is not null
							if(roleAssignment.getSource() != null){
								roleAssignSource = roleAssignment.getSource(); //eg spadmin

							}//end of if roleAssignment source is not null

							
						}//if roleAssignment roleId matched bundleID

						
					}//end of if roleAssignmentObj is not null
				}//iterating through roleAssignmentList
			}//end of if identityPreferenceObj is list
		}//end of if identityPreferenceObj is not null

		resultList.add(roleAssigner);
		resultList.add(roleAssignSource);

		
		return resultList;
	}

	
}
